
package tp5_g7;


import java.util.Arrays;


import org.junit.Test;
import static org.junit.Assert.*;


import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

/**
 En un tercer archivo parameterTest, cree una prueba parametrizada con el método
testDivCero. Use @RunWith(value=Parameterized.class) e Iterable<Object[]> tomarDatos
previo @Parameters para la suma usando conjuntos de valores como: 8, 7, 15, 2, 0, 20, y 10, -
1, -9. Devuelva Arrays.asList(new Object[][] {{ x,x,x}{x,x,x}}).
 */
@RunWith(Parameterized.class)
public class ParameterTest  {
    
    double a;
    double b;
    double resultadoEsperado;

      
    
 
    // Constructor parametrizado
    public ParameterTest(double a, double b, double resultadoEsperado) {
        
        this.a = a;
        this.b = b;
        this.resultadoEsperado = resultadoEsperado;
    }

    // 9. @Parameters: Datos para el test
    @Parameterized.Parameters
    public static Iterable<Object[]> tomarDatos() {
        return Arrays.asList(new Object[][] {
            {8, 7, 15.0},
            {2, 0, 2.0},
            {10, -1, 9.0},
            {-9, 9, 0.0}
        });
    }
 
    
    // Test parametrizado para la suma
    @Test
    public void testSumar() {
          
        Calculador calculador = new Calculador();
        double resultado = calculador.suma(a, b);
        assertEquals(resultadoEsperado, resultado, 0.001);
               
    }
 
}
