
package tp5_g7;


import org.junit.Before;



public class BaseTest {
    
  
   
    
    @Before
    public void before() {
        System.out.println("ejecutando el método de prueba: "+ Thread.currentThread().getStackTrace()[1].getMethodName() );
    }
    
   
}
