
package tp5_g7;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Test;

public class CalculadorTest  {

    private static Calculador calculador;
    
    // Use la annotation @BeforeClass para inicializar (new) el calculador 
    //y mostrar mensaje de bienvenida. Utilice la annotations:
    @Before
    public void setUp() {
        calculador = new Calculador();
        System.out.println("¡Bienvenido! iniciaremos las pruebas");
    }
    
    //@Before antes de cada método, que muestre un mensaje de la operación que se testea
    //Use System.out.println(Thread.currentThread().getStackTrace()[1].getMethodName() );
//    @Before
//    public void setUp() {
//        System.out.println("Test en ejecución: " + Thread.currentThread().getStackTrace()[1].getMethodName());
//    }
    
    //@After para que luego de cada método testeado que diga "Prueba finalizada, campos en 0”.
    @After
    public void tearDown() {
        System.out.println("Prueba finalizada, campos en 0.");
      
    }
    
    // Coloque un @AfterClass luego, que nos indique que “la operación ha finalizado”.
    @AfterClass
    public static void tearDownAfterClass() {
        System.out.println("La operación ha finalizado.");
        
    }

    // Use la anotación @Test y assertEquals para testear la resta y la suma use un delta de 0.001
    @Test
    public void testSuma() {
        System.out.println("Test en ejecución :"+ Thread.currentThread().getStackTrace()[1].getMethodName());
        double resultado = calculador.suma(5.5, 2.2);
        assertEquals(7.7, resultado, 0.001);  
    }

    @Test
    public void testResta() {
        System.out.println("Test en ejecución :"+ Thread.currentThread().getStackTrace()[1].getMethodName());
        double resultado = calculador.resta(10.5, 10.5);
        assertEquals(00.0, resultado, 0.001);  
    }
    
     @Test
  public void testMultiplicar(){
      System.out.println("Test en ejecución :"+ Thread.currentThread().getStackTrace()[1].getMethodName());
        double resultado = calculador.multiplicacion(9, 9);
        assertEquals(81, resultado, 0.001);  
  }
}
