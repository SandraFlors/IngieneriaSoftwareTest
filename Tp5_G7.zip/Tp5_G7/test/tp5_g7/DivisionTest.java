
package tp5_g7;



import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

/**
En otro archivo divisionTest, cree el método testDivisionCero use @Test (expected) que lance 
una AritmethicException.
 */
public class DivisionTest  {
    
    public DivisionTest() {
    }
    
   @Before
    public void setUp() {
        Calculador calculador = new Calculador();
        System.out.println("¡Bienvenido! iniciaremos las pruebas");
    }
    
       @Test(expected = ArithmeticException.class)
    public void testDivisionCero() {
        System.out.println("Test en ejecución :"+ Thread.currentThread().getStackTrace()[1].getMethodName());
        int a = 10;
        int b = 0;
        // Intentamos dividir entre cero
        int resultado = a / b;
        
    }
     @After
    public void tearDown() {
        System.out.println("Prueba finalizada, campos en 0.");
         
    }
    
   
    @AfterClass
    public static void tearDownAfterClass() {
        System.out.println("La operación ha finalizado.");
       
    }
}
