
package tp5_g7;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
    CalculadorTest.class,
    DivisionTest.class,
    ParameterTest.class
})
public class MiSweetSuite { //metodo que ejecutara todas las clases en orden anteriormente ordenados
   
}