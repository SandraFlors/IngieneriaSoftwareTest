
package tp5_g7;


public class Tp5_G7 {

   
    public static void main(String[] args) {
       
    }
    
}
