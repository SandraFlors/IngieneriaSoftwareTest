
package tp5_g7;


public class Calculador {
   double suma;
   double resta;
   int div;
   int mul;

    public Calculador() {
    }

    public Calculador(double suma, double resta, int div, int mul) {
        this.suma = suma;
        this.resta = resta;
        this.div = div;
        this.mul = mul;
    }

    public double getSuma() {
        return suma;
    }

    public void setSuma(double suma) {
        this.suma = suma;
    }

    public double getResta() {
        return resta;
    }

    public void setResta(double resta) {
        this.resta = resta;
    }

    public int getDiv() {
        return div;
    }

    public void setDiv(int div) {
        this.div = div;
    }

    public int getMul() {
        return mul;
    }

    public void setMul(int mul) {
        this.mul = mul;
    }
   public double suma(double n1 , double n2){
       return n1+n2;
   }

     public double resta(double n1 , double n2){
       return n1-n2;
   }
  
    public int multiplicacion(int n1,int n2){
        return n1*n2;
    }
      public int division(int n1,int n2){
        return n1/n2;
    }
}
